package ung.ungnewsletter.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import ung.ungnewsletter.model.Newsletter;

import java.io.IOException;

public class Controller {
    //@FXML specifies that these values are being drawn from the fxml file
    @FXML
    TextField txtcategory, txttitle, txtdescription, txtlink;

    //the button onaction event listener to submit the fxml form.
    public void SubmitRecord(javafx.event.ActionEvent actionEvent) {
        Newsletter mynewsletter = new Newsletter();

        mynewsletter.setCategory(txtcategory.getText());
        mynewsletter.setDescription(txtdescription.getText());
        mynewsletter.setLink(txtlink.getText());
        mynewsletter.setTitle(txttitle.getText());
        //calls save record in the Newsletter class. This takes each of the above
        //text fields and adds them to the database.
        mynewsletter.saverecord();
    }
    //specifies that this action is occuring in an fxml file
    @FXML
    //the name of the action as specified in the fxml file
    public void handlebuttonaction(ActionEvent event) throws IOException {
        //these load a new fxml file, set a new stage, set a new scene and show it.
        Parent otherpageparent = FXMLLoader.load(getClass().getResource("/ung/ungnewsletter/view/secondpage.fxml"));
        Scene otherpagescene = new Scene(otherpageparent);
        Stage newstage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        newstage.setScene(otherpagescene);
        newstage.show();
    }
}
