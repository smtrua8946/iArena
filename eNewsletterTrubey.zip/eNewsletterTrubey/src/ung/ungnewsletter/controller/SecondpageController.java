package ung.ungnewsletter.controller;

//controller for the second page. each page should have its own controller
public class SecondpageController {
}
