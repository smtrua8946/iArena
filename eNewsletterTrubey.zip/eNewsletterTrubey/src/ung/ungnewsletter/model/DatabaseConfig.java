package ung.ungnewsletter.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConfig {

    //username for the database server. usually root. can be renamed through mysql/mariadb
    private static final String USERNAME = "root";
    //password for the database server. usually empty by default. can be specified through mysql/mariadb
    private static final String PASSWORD = "iarena3300";
    //the url for the local source. In DataGrip it can be found in file -> data sources -> url
    private static final String CONN_STRING = "jdbc:mysql://localhost:3306/enewslettertrubeydb";

    // connection  method that connects us to the MySQL database
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
    }

    // method that displays our errors in more detail if connection fails
    public static void displayException(SQLException ex){

        System.err.println("Error Message: " + ex.getMessage());
        System.err.println("Error Code: " + ex.getErrorCode());
        System.err.println("SQL Status: " + ex.getSQLState());

    }
}