package ung.ungnewsletter.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Newsletter {
    private String category;
    private String title;
    private String description;
    private String link;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    //save record class that is called in the controller. adds the items in saveuserintodatabase to the database
    public int saverecord() {
        return saveUserIntoDatabase(getCategory(), getTitle(), getDescription(), getLink());
    }

    //method that establishes connection and adds the items to the database. Saveuserintodatabase,
    //saverecord, and submitrecord work together to do this.
    public int saveUserIntoDatabase(String category, String title, String description, String link) {
        int affectedRow = 0;
        //mysql commands to insert the data. newslettertable is the table that the data is being input into.
        String query = "insert into newslettertable" + "(category, title, description, link)"
                + "values(?,?,?,?)";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement sqlStatement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {
            sqlStatement.setString(1, category);
            sqlStatement.setString(2, title);
            sqlStatement.setString(3, description);
            sqlStatement.setString(4, link);

            // get the number of return rows
            affectedRow = sqlStatement.executeUpdate();

        } catch (Exception e) {
            System.out.println("Status: operation failed due to " + e);

        }
        return affectedRow;

    }
}
